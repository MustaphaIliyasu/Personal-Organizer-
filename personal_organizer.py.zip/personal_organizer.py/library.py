import random

books = []
           
def add_book():
    title = input("Enter a book title: ")
    author = input("Enter author")
    book_id = random.randint(100,1000)
    books.append({"id": book_id, "title": title, "author": author, "borrowed": False})
    print(f"{title} added with id {book_id}")
    

def view_books():
    if not books:
        print("No book in library. ")
    for b in books:
        status = "Borrowed" if b["borrowed"] else "Available"
        print(f"id: {b['id']} | {b['title']} by {b['author']} [{status}]")
    
    
def borrow_book():
    view_books()
    try:
        book_id = int(input("Enter book id to borrowed"))
        for b in books:
            if b['id'] == book_id and not b['borrowed']:
                b['borrowed'] = True
                print(f"you have borrowed '{b['title']}'")
                return
        print("book not fount or already borrowed")
    except:
        print("Invalid input")
        
        
def return_book():
        try:
            book_id = int(input("Enter book ID to return: ")) 
            for b in books:
                if b['id'] == book_id and b['borrowed']:
                    b['borrowed'] = False
                    print(f"You returnde '{b['title']}'")
                    return
                print("Book not found or not borrowed")    
        except:
            print("Invalide input")