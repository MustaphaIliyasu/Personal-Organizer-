from task import add_task, view_tack, mark_task_complete
from contact import add_contact, view_contact, search_contact
from student_grade import student_grade
from library import add_book, view_books, borrow_book, return_book
import os



def main():
    while True:
        print("\n Personal Oganizer App")
        print("1. Manage Tasks")
        print("2. Manage Contact")
        print("3. Mmanage Library")
        print("4. Student Grades")
        print("5. Exit")


        choice = input("Enter your choice")
        
        if choice == '1':
            print("\n****** Tasks Manager ******")
            print("1. Add task")
            print("2. View Task")
            print("3. Mark Task Coplete")
            sub = input("Choose: ")
            if sub == '1': add_task()
            elif sub == '2': view_tack()
            elif sub == '3': mark_task_complete
        elif choice == '2':
            print("\n****** Contact Book ******")
            print("1. Add Contact")
            print("2. View contact")
            print("3. Search Contact") 
            sun = input("Choose: ") 
            if sub == '1': add_contact()
            elif sub == '2': view_contact()
            elif sub == '3': search_contact()  
        elif choice == 3:
            print("\n****** Library ******")
            print("1. Add Book")
            print("2. View Book")
            print("3. Borrow Book") 
            print("4. Return Book")
            sun = input("Choose: ") 
            if sub == '1': add_book()
            elif sub == '2': view_books()
            elif sub == '3': borrow_book()
            elif sub == '4': return_book()
            
        elif choice == '4':
            student_grade()
            
        elif choice == '5':
            print("Goodbye")
            break
        else:
            print("Invalide choice")
            
        
if __name__ == "__main__":
    main()